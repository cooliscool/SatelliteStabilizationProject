#include "__cf_mainModel_matlab2013b_.h"
#ifndef RTW_HEADER_mainModel_matlab2013b__capi_h
#define RTW_HEADER_mainModel_matlab2013b__capi_h
#include "mainModel_matlab2013b_.h"
extern void mainModel_matlab2013b__InitializeDataMapInfo ( ) ;
#endif
