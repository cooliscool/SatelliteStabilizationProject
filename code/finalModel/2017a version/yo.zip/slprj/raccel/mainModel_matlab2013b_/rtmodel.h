#include "__cf_mainModel_matlab2013b_.h"
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "mainModel_matlab2013b_.h"
#define GRTINTERFACE 1
#endif
